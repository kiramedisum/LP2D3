<?php

include 'navbar.php';

include 'inde2x.html';


include 'footer.php';

?>