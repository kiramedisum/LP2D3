<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class CafeBistroController extends BaseController
{
public function listarCafes()
{
    $cafes = [
        'Café com leite',
        'Café gelado',
        'Café cremoso',
        'Cappucino'
    ];
    $html = '<ul>';
    foreach ($cafes as $cafe){
        $html .= "<li>$cafe</li>";
    }
    $html .= '</ul>';
    echo $html;
    }

}
