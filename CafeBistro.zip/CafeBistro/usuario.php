<?php
class usuario {
    private $nome;
    private $email;
    private $senha;

    function __construct($nome,$email,$senha){
        $this->nome = $nome;
        $this->email = $email;
        $this->senha = $senha;
    }

    function get_nome(){
        return $this->nome;
    }
    
    function get_email(){
        return $this->email;
    }
    
    function get_senha(){
        return $this->senha;
    }
    
    function set_nome($nome){
        $this->nome = $nome;
    }
    
    function set_email($email){
        $this->email = $email;
    }
    
    function set_senha($senha){
        $this->senha = $senha;
    }

    function cadastrar($nome,$email,$senha){
        $senhaHash = password_hash($senha, PASSWORD_DEFAULT);
        $sql = "INSERT INTO usuario(nome,email,senha) VALUES (?,?,?)";
    }

    

}
